Comic Mischief Detection Task

Files:

1. "Dataset_ComicMischief_Training_Scene_Binary_Annotations.csv" : 
-- Contains binary classification content annotations for each video scene used in the training set.
-- Annotations correspond to the presence of content mischief content on a scene level, regardless of content type
-- a ".csv" file containing video URLs as well as the IDs of the scenes used in the training set.
-- Videos are available in the form of URLs, collected from the Youtube and the IMDB websites.
-- Contains metadata about the videos.

2. "binary_detection.sol" : 
-- Ground truth labels for the binary detection task (track 1) in the training set. There is one line per each of the videos in the binary_detection_metadata.csv file. 
-- Submissions to track 1 should adhere to this format.


3. "Dataset_ComicMischief_Training_Scene_Multiclass_Annotations.csv" : 
-- Contains multiclass classification content annotations for each video scene used in the training set.
-- Annotations are on a scene level and do not correspond to a specific modality
-- a ".csv" file containing video URLs as well as the IDs of the scenes used in the training set.
-- Videos are available in the form of URLs, collected from the Youtube and the IMDB websites.
-- Contains metadata about the videos.
-- Four content categories related to comic mischief are used (Sarcasm, Slapstick Humor, Gory Humor, Mature Humor).

4. "finegrained_detection.sol" : 
-- Ground truth labels for the fine grained detection task (track 2) in the training set. There is one line per each of the videos in the finegrained_detection_metadata.csv file, 
-- and there is a column per each of the considered labels as indicated in the finegrained_detection_metadata.csv. Submissions to track 2 should adhere to this format.



Training Set Generation Script Pipeline:

1. "1.download_training_videos.py":
-- A script that automatically downloads the videos using the URLs contained in the "Dataset_ComicMischief_Training.csv".
-- After each video is downloaded, its ID and URL along with its metadata are printed on the screen.
-- When the script finishes, it reports how many videos were successfully downloaded and how many were missing.
-- Downloaded videos are stored in the "./videos" directory.

2. "2.generate_1min_scenes.py":
-- A script that uses FFmpeg to segment videos into one-minute scenes.
-- All scenes for each video are stored in the "./scenes" directory.
-- The scenes contained in the "./scenes" directory do not form the training set. To obtain the training set, the following script in the pipeline needs to be executed.

3. "3.prepare_training_data_directory.py":
-- A script that prepares the training data directory.
-- The scenes from all videos that are specifically used to form the training set are stored in the "training_data" directory.
-- The video scene files contained in the "training_data" can be directly mapped to the video scenes discussed in the "Dataset_ComicMischief_Training.csv", to obtain the respective annotations.
-- When the script finishes, it reports how many scenes were successfully moved to the "training_data" directory and how many were missing.

The script pipeline was developed and tested in Ubuntu 20.04, using Python 3.
The following Python dependencies need to be satisfied to use the scripts:
1. FFmpeg
2. pip install pandas
3. pip install pytube==10.4.1
4. pip install -U get-video-properties

The scripts of the pipeline need to be executed in the order that the numeric digit at the beginning of their filename indicates to form the training set.


