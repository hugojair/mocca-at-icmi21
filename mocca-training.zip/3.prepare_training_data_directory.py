#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import shutil
import pandas as pd


scenesDirectory="scenes/"
trainingDataDirectory="training_data/"

if not os.path.exists(trainingDataDirectory):
    os.makedirs(trainingDataDirectory)
    
csvFile=pd.read_csv('Dataset_ComicMischief_Training_Scene_Multiclass_Annotations.csv')  

totalSuccessfullAttempts=0
totalFailedAttempts=0
for i,videoID in enumerate(csvFile["Video ID"]):
    try:
        sceneID = str(csvFile["Scene_ID"][i])
    
        shutil.copyfile(scenesDirectory+videoID+"/"+videoID+".0"+sceneID+".mp4", trainingDataDirectory+videoID+".0"+sceneID+".mp4")
        print("Video ID:",videoID,"Scene ID:",sceneID, "Successfully extracted")
        totalSuccessfullAttempts+=1
    except:
        print("Video ID:",videoID,"Scene ID:",sceneID, "Failed")
        totalFailedAttempts+=1
print("Total Successfull Scene Extraction Attempts = ", totalSuccessfullAttempts)
print("Total Failed Scene Extraction Attempts = ", totalFailedAttempts)

    
