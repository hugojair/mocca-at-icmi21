#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import subprocess


def split_video(file):
    input_file="videos/"+file
    output_dir="scenes/"+file.split(".")[0]
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    result = subprocess.run(["ffmpeg", "-i", input_file,"-map","0", "-c", "copy", "-f", "segment", "-segment_time", "60","-reset_timestamps", "1", output_dir+"/"+file.split(".")[0]+".%02d."+file.split(".")[-1]],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT)
    
for video in os.listdir("videos/"):
    print(video)
    split_video(video)