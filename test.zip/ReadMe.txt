Comic Mischief Detection Task

Files:

1. "Dataset_ComicMischief_Training_Scene_Multiclass_Annotations.csv" : 
-- Contains multiclass classification content annotations for each video scene used in the training set.
-- Annotations are on a scene level and do not correspond to a specific modality
-- a ".csv" file containing video URLs as well as the IDs of the scenes used in the training set.
-- Videos are available in the form of URLs, collected from the Youtube and the IMDB websites.
-- Contains metadata about the videos.
-- Four content categories related to comic mischief are used (Sarcasm, Slapstick Humor, Gory Humor, Mature Humor).

2. "Dataset_ComicMischief_Training_Scene_Binary_Annotations.csv" : 
-- Contains binary classification content annotations for each video scene used in the training set.
-- Annotations correspond to the presence of content mischief content on a scene level, regardless of content type
-- a ".csv" file containing video URLs as well as the IDs of the scenes used in the training set.
-- Videos are available in the form of URLs, collected from the Youtube and the IMDB websites.
-- Contains metadata about the videos.

3. "Dataset_ComicMischief_Test_Scenes" : 
-- Contains the list of video scenes used in the test set. No groundtruth annotations are provided for the test set.

4. "sample-submissions-test" folder
-- It includes sample submission files for the binary and fine grained tasks. Please prepare your submissions for the test phase in a similar way. 

5. "*sol files"
-- Ground truth labels for the training scenes in the submission format

Datasetset Generation Script Pipeline:

1. "1.download_videos.py":
-- A script that automatically downloads the videos using the URLs contained in the .csv files
-- After each video is downloaded, its ID and URL along with its metadata are printed on the screen.
-- When the script finishes, it reports how many videos were successfully downloaded and how many were missing.
-- Downloaded videos are stored in the "./train_videos" and "./test_videos" directories.
-- The script attempts to download each video four times, otherwise the attempt is considered as "failed"
-- A common reason for failure in downloading the video, is a Uoutube account being terminated 

2. "2.generate_1min_scenes.py":
-- A script that uses FFmpeg to segment videos into one-minute scenes.
-- All scenes for each video are stored in the "./train_scenes" and "./test_scenes" directories.
-- The scenes contained in the "./****_scenes" directories do not form the final dataset partitions. To obtain the final dataset partitions, the following script in the pipeline needs to be executed.

3. "3.prepare_dataset_directories.py":
-- A script that prepares the dataset training and testing set directories.
-- The scenes from all videos that are specifically used to form the training set are stored in the "training_data" directory.
-- The scenes from all videos that are specifically used to form the test set are stored in the "test_data" directory.
-- The video scene files contained in the "training_data" can be directly mapped to the video scenes discussed in the "Dataset_ComicMischief_Training_Scenes_******.csv", to obtain the respective annotations.
-- The video scene files contained in the "test_data" can be directly mapped to the video scenes discussed in the "Dataset_ComicMischief_Test_Scenes.csv", to obtain the respective annotations.
-- When the script finishes, it reports how many scenes were successfully moved to the "****_data" directories and how many were missing.

The script pipeline was developed and tested in Ubuntu 20.04, using Python 3.
The following Python dependencies need to be satisfied to use the scripts:
1. FFmpeg
2. pip install pandas
3. pip install pytube==10.8.5
4. pip install -U get-video-properties

The scripts of the pipeline need to be executed in the order that the numeric digit at the beginning of their filename indicates to form the training set.


