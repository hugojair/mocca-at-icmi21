#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import shutil
import pandas as pd



partitions=["train","test"]
csv_files=["Dataset_ComicMischief_Training_Scene_Binary_Annotations.csv","Dataset_ComicMischief_Test_Scenes.csv"]

for partition_index,partition in enumerate(partitions):
    if os.path.exists(csv_files[partition_index]):
        if os.path.exists(partition+"_videos/"):
            output_path=partition+"_data/"    
            if not os.path.exists(output_path):
                os.mkdir(output_path)
            final_videos=[]
            
            csvFile=pd.read_csv(csv_files[partition_index])  
            scenesDirectory=partition+"_scenes/"
        
            
            if not os.path.exists(output_path):
                os.makedirs(output_path)
            
            totalSuccessfullAttempts=0
            totalFailedAttempts=0
            for i,videoID in enumerate(csvFile["Video ID"]):
                try:
                    sceneID = str(csvFile["Scene_ID"][i])
                    if (len(str(sceneID))<2):
                        shutil.copyfile(scenesDirectory+videoID+"/"+videoID+".0"+sceneID+".mp4", output_path+videoID+".0"+sceneID+".mp4")
                    else:
                        shutil.copyfile(scenesDirectory+videoID+"/"+videoID+"."+sceneID+".mp4", output_path+videoID+".0"+sceneID+".mp4")            
                    print("Video ID:",videoID,"Scene ID:",sceneID, "Successfully extracted")
                    totalSuccessfullAttempts+=1
                except:
                    print("Video ID:",videoID,"Scene ID:",sceneID, "Failed")
                    totalFailedAttempts+=1
            print("Total Successfull Scene Extraction Attempts = ", totalSuccessfullAttempts)
            print("Total Failed Scene Extraction Attempts = ", totalFailedAttempts)

    
